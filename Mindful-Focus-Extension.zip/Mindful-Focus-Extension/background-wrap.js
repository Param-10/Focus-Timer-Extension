try {
    importScripts('background-core.js');
  } catch (e) {
    console.error("Error in background script:", e);
  }